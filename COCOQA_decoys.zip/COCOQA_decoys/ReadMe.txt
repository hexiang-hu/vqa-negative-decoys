(1) We provide our generated decoys for COCO-QA in 2 json files:

COCOQA_train_decoys.json 
COCOQA_test_decoys.json 

The training/test splits for COCO-QA exactly follow the original datasets.



(2) Each json file contains a list. Each item of the list is like follows,

{"QoU_decoys": ["umbrellas", "dryer", "cow"], "question": "what is using umbrellas as a central theme", "image_id": 397899, "answer": "sculpture", "IoU_decoys": ["white", "umbrellas", "brown"], "type": 0}
"QoU_decoys": a list of 3 QoU decoys.
"IoU_decoys": a list of 3 IoU decoys.
"image_id": follow the original dataset.
"question": follow the original dataset.
"answer": follow the original dataset.
"type": follow the original dataset.

The "question", "answer", "image_id", and "type" follow the original dataset.
The original dataset can be downloaded from: 
COCO-QA: http://www.cs.toronto.edu/~mren/imageqa/data/cocoqa/

Note that, the order of items in our lists follows exactly the same as those in COCO-QA for each split. 



(3) If you use our datasets for any published research, it would be nice if you would cite our paper as well as the corresponding paper of the original dataset.

@inproceedings{chao2018being,
  title={Being Negative but Constructively: Lessons Learnt from Creating Better Visual Question Answering Datasets},
  author={Chao, Wei-Lun and Hu, Hexiang and Sha, Fei},
  booktitle={NAACL},
  year={2018}
}

@inproceedings{ren2015exploring,
  title={Exploring models and data for image question answering},
  author={Ren, Mengye and Kiros, Ryan and Zemel, Richard},
  booktitle={Advances in neural information processing systems},
  pages={2953--2961},
  year={2015}
}