(1) We provide our generated decoys for Visual Genome (v1.2) in 3 json files:

VG_train_decoys.json 
VG_val_decoys.json 
VG_test_decoys.json

We split the dataset into 50%/20%/30% for training/validation/test. We partition such that each portion is a �superset� of the corresponding one in Visual7W, respectively.



(2) Each json file contains a list. Each item of the list is like follows,

{"QoU_decoys": ["Blue.", "Black.", "White."], "image_id": 2, "question": "What color is the car?", "qa_id": 986934, "answer": "Red.", "IoU_decoys": ["A backpack.", "Glass.", "Parked on the street."]}.

"QoU_decoys": a list of 3 QoU decoys.
"IoU_decoys": a list of 3 IoU decoys.
"image_id": follow the original dataset.
"qa_id": follow the original dataset.
"question": the question in the original dataset.
"answer": the correct answer (target) in the original dataset.

The "question", "answer", "image_id", and "qa_id" follow the original dataset.
The original dataset can be downloaded from: 
Visual Genome (v1.2): http://visualgenome.org/api/v0/api_home.html



(3) If you use our datasets for any published research, it would be nice if you would cite our paper as well as the corresponding paper of the original dataset.

@article{chao2017being,
  title={Being Negative but Constructively: Lessons Learnt from Creating Better Visual Question Answering Datasets},
  author={Chao, Wei-Lun and Hu, Hexiang and Sha, Fei},
  journal={arXiv preprint arXiv:1704.07121},
  year={2017}
}

@article{krishna2017visualgenome,
  title={Visual Genome: Connecting Language and Vision Using Crowdsourced Dense Image Annotations},
  author={Krishna, Ranjay and Zhu, Yuke and Groth, Oliver and Johnson, Justin and Hata, Kenji and Kravitz, Joshua and Chen, Stephanie and Kalantidis, Yannis and Li, Li-Jia and Shamma, David A and Bernstein, Michael and Fei-Fei, Li},
  journal={IJCV},
  year = {2017}
}