(1) We provide our generated decoys for VQA (v1.0) (real-image) in 2 json files:

vqa_train2014_decoys.json
vqa_val2014_decoys.json


The training/validation/test splits for VQA exactly follow the original datasets.



(2) Each json file contains a list. Each item of the list is like follows,

{"QoU_decoys": ["Blue.", "Black.", "White."], "image_id": 2, "question_id": 986934, "IoU_decoys": ["A backpack.", "Glass.", "Parked on the street."]}.

"QoU_decoys": a list of 3 QoU decoys.
"IoU_decoys": a list of 3 IoU decoys.
"image_id": follow the original dataset.
"question_id": follow the original dataset.

You can find the "answer_type",  "question_type", "question", and "(correct) multiple_choice_answer" from the original dataset.
The "image_id", and "question_id" follow the original dataset.
The original dataset can be downloaded from: 
VQA (v1.0): http://www.visualqa.org/vqa_v1_download.html

Note that, the order of items in our lists follows exactly the same as those in VQA for each split. 



(3) If you use our datasets for any published research, it would be nice if you would cite our paper as well as the corresponding papers of the original dataset.

@article{chao2017being,
  title={Being Negative but Constructively: Lessons Learnt from Creating Better Visual Question Answering Datasets},
  author={Chao, Wei-Lun and Hu, Hexiang and Sha, Fei},
  journal={arXiv preprint arXiv:1704.07121},
  year={2017}
}

@InProceedings{{VQA}, 
author = {Stanislaw Antol and Aishwarya Agrawal and Jiasen Lu and Margaret Mitchell and Dhruv Batra and C. Lawrence Zitnick and Devi Parikh}, 
title = {{VQA}: {V}isual {Q}uestion {A}nswering}, 
booktitle = {International Conference on Computer Vision (ICCV)}, 
year = {2015}, 
}

@inproceedings{lin2014microsoft,
  title={Microsoft coco: Common objects in context},
  author={Lin, Tsung-Yi and Maire, Michael and Belongie, Serge and Hays, James and Perona, Pietro and Ramanan, Deva and Doll{\'a}r, Piotr and Zitnick, C Lawrence},
  booktitle={European Conference on Computer Vision},
  pages={740--755},
  year={2014},
  organization={Springer}
}