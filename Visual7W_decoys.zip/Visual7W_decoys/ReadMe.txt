(1) We provide our generated decoys for Visual7W (v1.1) (telling) in 3 json files:

v7w_train_decoys.json 
v7w_val_decoys.json 
v7w_test_decoys.json 

The training/validation/test splits for Visual7W exactly follow the original datasets.



(2) Each json file contains a list. Each item of the list is like follows,

{"QoU_decoys": ["Blue.", "Black.", "White."], "Img_id": 2, "QA_id": 986934, "IoU_decoys": ["A backpack.", "Glass.", "Parked on the street."]}.

"QoU_decoys": a list of 3 QoU decoys.
"IoU_decoys": a list of 3 IoU decoys.
"Img_id": follow the original dataset.
"QA_id": follow the original dataset.

You can find the "question type", "question", and "correct answer" from the original dataset.
The "Img_id", and "QA_id" follow the original dataset.
The original dataset can be downloaded from: 
Visual7W (v1.1): https://web.stanford.edu/~yukez/visual7w/index.html

Note that, the order of items in our lists follows exactly the same as those in Visual7W for each split. 



(3) If you use our datasets for any published research, it would be nice if you would cite our paper as well as the corresponding paper of original dataset.

@inproceedings{zhu2016visual7w,
  title={Visual7w: Grounded question answering in images},
  author={Zhu, Yuke and Groth, Oliver and Bernstein, Michael and Fei-Fei, Li},
  booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
  pages={4995--5004},
  year={2016}
}